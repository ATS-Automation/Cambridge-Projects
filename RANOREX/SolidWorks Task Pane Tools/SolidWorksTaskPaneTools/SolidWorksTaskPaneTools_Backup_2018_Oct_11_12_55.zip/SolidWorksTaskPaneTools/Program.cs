﻿/*
 * Created by Ranorex
 * User: abridgman
 * Date: 12/6/2016
 * Time: 9:38 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Threading;
using System.Drawing;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Reporting;
using Ranorex.Core.Testing;

namespace SolidWorksTaskPaneTools
{
    class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            // Uncomment the following 2 lines if you want to automate Windows apps
            // by starting the test executable directly
            //if (Util.IsRestartRequiredForWinAppAccess)
            //    return Util.RestartWithUiAccess();

            var repo = SolidWorksTaskPaneToolsRepository.Instance;
            PopupWatcher myPopupWatcher = new PopupWatcher();  
            myPopupWatcher.WatchAndClick(repo.SolidWorks.ButtonOKInfo, repo.SolidWorks.ButtonOKInfo);
            myPopupWatcher.WatchAndClick(repo.SOLIDWORKS1.ButtonOKInfo, repo.SOLIDWORKS1.ButtonOKInfo);
            myPopupWatcher.WatchAndClick(repo.ConfirmSaveAs.ButtonYesInfo, repo.ConfirmSaveAs.ButtonYesInfo);
            
            myPopupWatcher.Start(); 
            
            Keyboard.AbortKey = System.Windows.Forms.Keys.Pause;
            int error = 0;

            try
            {
                error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);
            }
            catch (Exception e)
            {
                Report.Error("Unexpected exception occurred: " + e.ToString());
                error = -1;
            }
            return error;
        }
    }
}
